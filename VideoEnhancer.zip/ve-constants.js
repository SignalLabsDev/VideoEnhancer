(function(){
  const VN = window.VideoEnhancer || (window.VideoEnhancer = {});

  // Prevent re-initialization if already loaded
  if (VN.constantsInitialized) return;
  VN.constantsInitialized = true;

  // IDs and keys
  const FILTER_ID = `video-enhancer-filter-${Math.random().toString(36).slice(2)}`;
  VN.ids = {
    FILTER_ID,
    DATA_APPLIED_KEY: 'videoEnhancerApplied',
    DATA_ORIGINAL_FILTER_KEY: 'videoEnhancerOriginalFilter',
    DATA_SETTINGS_KEY: 'videoEnhancerSettingsToken',
    DATA_CURRENT_FILTER_KEY: 'videoEnhancerCurrentFilter'
  };

  // Defaults
  const PRESET_SETTINGS = Object.freeze({
    sharpen: 0.3,
    contrast: 1.0,
    saturation: 1.15,
    brightness: 1.0,
    gamma: 1.1
  });

  VN.DEFAULT_SETTINGS = Object.freeze({
    sharpen: PRESET_SETTINGS.sharpen,
    contrast: PRESET_SETTINGS.contrast,
    saturation: PRESET_SETTINGS.saturation,
    brightness: PRESET_SETTINGS.brightness,
    gamma: PRESET_SETTINGS.gamma
  });

  // Neutral values remove all Video Enhancer adjustments from the video.
  VN.NEUTRAL_SETTINGS = Object.freeze({
    sharpen: 0,
    contrast: 1,
    saturation: 1,
    brightness: 1,
    gamma: 1
  });

  const SETTING_RANGES = Object.freeze({
    sharpen: [0, 1.5],
    contrast: [0.5, 2],
    saturation: [0.5, 2],
    brightness: [0.5, 2],
    gamma: [0.5, 2]
  });

  VN.normalizeSettings = (settings, fallback = VN.DEFAULT_SETTINGS) => {
    const normalized = {};
    Object.entries(SETTING_RANGES).forEach(([key, [min, max]]) => {
      const value = Number(settings?.[key]);
      const fallbackValue = Number(fallback?.[key]);
      const safeValue = Number.isFinite(value) ? value : fallbackValue;
      normalized[key] = Number(Math.min(max, Math.max(min, safeValue)).toFixed(3));
    });
    return normalized;
  };

  VN.state = {
    enabled: true,
    panelVisible: false,
    activeTab: 'preset',
    compatibilityMode: false,
    overlayEnabled: true,
    settings: { ...VN.DEFAULT_SETTINGS },
    presets: [],
    panelPosition: { useCustom: false, top: 80, left: null }
  };

  VN.consts = {
    STORAGE_KEY: 'videoEnhancerState',
    STORAGE_VERSION: 1,
    PERSIST_DEBOUNCE_MS: 250,
    MIN_TARGET_WIDTH: 320,
    MIN_TARGET_HEIGHT: 180
  };

  // Persistence
  let persistTimer = null;
  
  const buildPersistSnapshot = () => ({
    version: VN.consts.STORAGE_VERSION,
    timestamp: Date.now(),
    data: {
      enabled: VN.state.enabled,
      panelVisible: VN.state.panelVisible,
      activeTab: VN.state.activeTab,
      compatibilityMode: VN.state.compatibilityMode,
      overlayEnabled: VN.state.overlayEnabled,
      settings: { ...VN.state.settings },
      presets: VN.state.presets.map((preset) => ({
        id: preset.id,
        name: preset.name,
        settings: { ...preset.settings }
      })),
      panelPosition: { ...VN.state.panelPosition }
    }
  });

  VN.schedulePersist = () => {
    if (!chrome?.storage?.local) return;
    if (persistTimer) clearTimeout(persistTimer);
    persistTimer = setTimeout(() => {
      persistTimer = null;
      const snapshot = buildPersistSnapshot();
      try { chrome.storage.local.set({ [VN.consts.STORAGE_KEY]: snapshot }); } catch (_) {}
    }, VN.consts.PERSIST_DEBOUNCE_MS);
  };

  // Apply state from storage (used for cross-tab sync)
  const applyStorageState = (snapshot, skipPanelVisible = true) => {
    if (!snapshot || typeof snapshot !== 'object') return false;
    
    let changed = false;
    
    if (typeof snapshot.enabled === 'boolean' && VN.state.enabled !== snapshot.enabled) {
      VN.state.enabled = snapshot.enabled;
      changed = true;
    }
    
    // Skip panelVisible sync - each tab manages its own panel
    if (!skipPanelVisible && typeof snapshot.panelVisible === 'boolean') {
      VN.state.panelVisible = snapshot.panelVisible;
    }
    
    if ((snapshot.activeTab === 'custom' || snapshot.activeTab === 'preset') && VN.state.activeTab !== snapshot.activeTab) {
      VN.state.activeTab = snapshot.activeTab;
      changed = true;
    }
    
    if (typeof snapshot.compatibilityMode === 'boolean' && VN.state.compatibilityMode !== snapshot.compatibilityMode) {
      VN.state.compatibilityMode = snapshot.compatibilityMode;
      changed = true;
    }
    
    if (typeof snapshot.overlayEnabled === 'boolean' && VN.state.overlayEnabled !== snapshot.overlayEnabled) {
      VN.state.overlayEnabled = snapshot.overlayEnabled;
      changed = true;
    }
    
    if (snapshot.settings && typeof snapshot.settings === 'object') {
      const normalizedSettings = VN.normalizeSettings(snapshot.settings, VN.state.settings);
      if (Object.keys(normalizedSettings).some((key) => normalizedSettings[key] !== VN.state.settings[key])) {
        VN.state.settings = normalizedSettings;
        changed = true;
      }
    }

    if (Array.isArray(snapshot.presets)) {
      const normalizedPresets = snapshot.presets
        .slice(0, 50)
        .filter((preset) => preset && typeof preset === 'object')
        .map((preset, index) => {
          const name = typeof preset.name === 'string' ? preset.name.trim().slice(0, 40) : '';
          const id = typeof preset.id === 'string' && preset.id.length <= 100
            ? preset.id
            : `saved-${index}`;
          if (!name) return null;
          return {
            id,
            name,
            settings: VN.normalizeSettings(preset.settings, VN.DEFAULT_SETTINGS)
          };
        })
        .filter(Boolean);
      if (JSON.stringify(normalizedPresets) !== JSON.stringify(VN.state.presets)) {
        VN.state.presets = normalizedPresets;
        changed = true;
      }
    }
    
    // Sync panel position with validation
    if (snapshot.panelPosition && typeof snapshot.panelPosition === 'object') {
      const pos = snapshot.panelPosition;
      const newPos = {
        useCustom: Boolean(pos.useCustom),
        top: (typeof pos.top === 'number' && isFinite(pos.top)) ? pos.top : VN.state.panelPosition.top,
        left: (typeof pos.left === 'number' && isFinite(pos.left)) ? pos.left : VN.state.panelPosition.left
      };
      
      if (newPos.useCustom !== VN.state.panelPosition.useCustom || 
          newPos.top !== VN.state.panelPosition.top || 
          newPos.left !== VN.state.panelPosition.left) {
        VN.state.panelPosition = newPos;
        changed = true;
      }
    }
    
    return changed;
  };

  // Per-tab state: Each tab loads from storage on init but doesn't sync with other tabs.
  // This is simpler and more reliable than cross-tab synchronization.

  VN.loadPersistedState = () => new Promise((resolve) => {
    if (!chrome?.storage?.local) { resolve(); return; }
    try {
      chrome.storage.local.get(VN.consts.STORAGE_KEY, (result) => {
        const payload = result?.[VN.consts.STORAGE_KEY];
        const snapshot = payload && typeof payload === 'object'
          ? (payload.data && typeof payload.data === 'object' ? payload.data : payload)
          : null;
        
        // Load all state from storage on init
        applyStorageState(snapshot, false);
        resolve();
      });
    } catch (_) { resolve(); }
  });

  // Listen for storage changes to sync state across frames/tabs
  if (chrome?.storage?.onChanged) {
    chrome.storage.onChanged.addListener((changes, areaName) => {
      if (areaName !== 'local' || !changes[VN.consts.STORAGE_KEY]) return;
      
      const payload = changes[VN.consts.STORAGE_KEY].newValue;
      const snapshot = payload && typeof payload === 'object'
        ? (payload.data && typeof payload.data === 'object' ? payload.data : payload)
        : null;
      
      if (applyStorageState(snapshot)) {
        // If state changed, trigger a refresh in this frame
        VN.panel?.syncUI?.();
        VN.scheduleRefresh?.('storage-sync');
        VN.overlay?.refresh?.();
      }
    });
  }

  /**
   * Deeply collects all video elements, including those inside open Shadow Roots.
   */
  VN.collectVideos = () => {
    const found = [];
    const stack = [document.documentElement];
    const seen = new Set();

    while (stack.length) {
      const node = stack.pop();
      if (!node || seen.has(node)) continue;
      seen.add(node);

      if (node instanceof HTMLVideoElement) {
        found.push(node);
        continue;
      }

      if (node instanceof Element) {
        const sr = node.shadowRoot;
        if (sr && sr.mode === 'open') {
          stack.push(sr);
        }
      }

      if (node instanceof DocumentFragment || node instanceof Element || node instanceof Document) {
        const children = node.childNodes;
        if (children && children.length) {
          for (let i = children.length - 1; i >= 0; i -= 1) {
            stack.push(children[i]);
          }
        }
      }
    }
    return found;
  };
})();
